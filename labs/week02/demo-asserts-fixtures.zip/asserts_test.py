import unittest

from bank_account import BankAccount

def setUpModule():
    print('Executing setUpModule')

def tearDownModule():
    print('Executing tearDownModule')

class TestAsserts(unittest.TestCase):
    '''
    Validates each type of assert available with unittest framework
    '''

    @classmethod
    def setUpClass(cls) -> None:
        print('Executing setUpClass')

    @classmethod
    def tearDownClass(cls) -> None:
        print('Executing tearDownClass')

    def setUp(self) -> None:
        print('Executing setUp')
        self.bank_account1 = BankAccount('Melissa Testing', 25.00)
        self.bank_account2 = BankAccount('Melissa Testing', 25.00)
        self.bank_account3 = BankAccount('Bob Roberts', 25.00)

    def tearDown(self) -> None:
        print('Executing tearDown')

    def test_assertEqual(self):
        print('Executing test_assertEqual')
        self.assertEqual(self.bank_account1, self.bank_account2)
    
    def test_assertNotEqual(self):
        self.assertNotEqual(self.bank_account1, self.bank_account3)

    def test_assertTrue(self):
        self.bank_account1.deposit(25.00)
        self.assertTrue(self.bank_account1.balance == 50)

    def test_assertIs(self):
        bank_account_copy = self.bank_account1
        self.assertIs(self.bank_account1, bank_account_copy)

    def test_assertIn(self):
        bank_account_local = BankAccount('Melissa Testing', 25.00)
        accounts = [self.bank_account1, self.bank_account2, self.bank_account3]
        self.assertIn(self.bank_account1, accounts)
        # self.assertNotIn(bank_account_local, accounts)

if __name__ == '__main__':
    unittest.main()